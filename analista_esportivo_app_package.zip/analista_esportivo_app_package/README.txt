Analista Esportivo - preparo do projeto
======================================
Este zip contém seu código integrado ao esqueleto Briefcase/BeeWare.
Para gerar o APK no Termux siga os passos no README_GENERATE_APK.md.